<script>
  $(document).ready(function(){
    $('#textSlider').carousel({
      interval: 1000 // Change slide every 2 seconds
    })
  })
</script>
